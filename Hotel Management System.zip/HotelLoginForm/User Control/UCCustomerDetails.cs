﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HotelLoginForm.User_Control
{
    public partial class UCCustomerDetails : UserControl
    {
        public UCCustomerDetails()
        {
            InitializeComponent();
        }

        private void btnAddRoom_Click(object sender, EventArgs e)
        {

            
          
        }

        private void UCCustomerDetails_Load(object sender, EventArgs e)
        {
            
            string con = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Kevin\Documents\HotelDB.mdf;Integrated Security=True;Connect Timeout=30";
            string qry = "SELECT * FROM CustomerDetails";

            try
            {
                SqlDataAdapter da = new SqlDataAdapter(qry, con);
                DataSet ds = new DataSet();

                da.Fill(ds, "CustomerDetails");
                DGVCustomer.DataSource = ds.Tables["CustomerDetails"];
            }

            catch(SqlException SE)
            {
                MessageBox.Show(SE.ToString());
            }

            
        }

        private void DGVCustomer_Enter(object sender, EventArgs e)
        {
            UCCustomerDetails_Load(this, null);
        }

        private void UCCustomerDetails_Leave(object sender, EventArgs e)
        {
            clearAll();
        }

        private void clearAll()
        {
            txtSearchType.SelectedIndex = -1;
        }
    }
}
