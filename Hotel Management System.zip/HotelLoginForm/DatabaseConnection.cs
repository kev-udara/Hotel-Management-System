﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace HotelLoginForm
{
    class DatabaseConnection
    {
        public string DataConnection(string QRY)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Kevin\Documents\HotelDB.mdf;Integrated Security=True;Connect Timeout=30");
            SqlCommand cmd = new SqlCommand(QRY, con);

            try
            {
                con.Open();
                cmd.ExecuteNonQuery();
                return "Operation executed successfully";
            }

            catch(SqlException SE)
            {
                return "Operation was not successfull"+SE;
            }

            finally
            {
                con.Close();
            }
        }

        
           
        
    }
}
